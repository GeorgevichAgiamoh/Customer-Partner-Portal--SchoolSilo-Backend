<!DOCTYPE html>
<html>
<head>
    <title><?php echo e(config('app.name', 'Stable Shield')); ?> API</title>
</head>
<body>
    <h1>Home</h1>
    <p>This is just the hompage of <?php echo e(config('app.name', 'Stable Shield')); ?> API, please refer to the docs to access endpoints</p>
    <div style="margin-top: 50px;width:100%;display:flex;align-items:center;justify-content:center">
        <p style="color: #cccccc;">POWERED BY <a href="https://stableshield.com">STABLE SHIELD SOLUTIONS</a></p>
    </div>
</body>
</html><?php /**PATH C:\xampp\htdocs\nacdded_backend\resources\views/welcome.blade.php ENDPATH**/ ?>