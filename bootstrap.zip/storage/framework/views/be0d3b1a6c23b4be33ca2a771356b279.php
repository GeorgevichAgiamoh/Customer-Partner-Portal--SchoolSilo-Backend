<!DOCTYPE html>
<html>
<head>
    <title><?php echo e(config('app.name', 'Stable Shield')); ?> Mail</title>
</head>
<body>
    <h1>Hello, <?php echo e($data['name']); ?>!</h1>
    <p><?php echo e($data['body']); ?></p>
    <a href="<?php echo e($data['link']); ?>" style="margin-top: 50px;"><?php echo e($data['link']); ?></a>
    <div style="margin-top: 50px;width:100%;display:flex;align-items:center;justify-content:center">
        <p style="color: #cccccc;">POWERED BY <a href="https://stableshield.com">STABLE SHIELD SOLUTIONS</a></p>
    </div>
</body>
</html><?php /**PATH C:\xampp\htdocs\sss\schoolsilo_backend\resources\views/emails/mail_template.blade.php ENDPATH**/ ?>