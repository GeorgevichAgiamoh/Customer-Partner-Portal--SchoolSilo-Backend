# SCHOOLSILO Backend


## Info
Company: Stable Shield Solutions

Developer: Daniel, Remote fullstack developer

Technology: PHP, Laravel, MySQL

Started: 15/2/24



## Progress Update

> Setting up authentication REST API (DONE)

> User data upload endpoint (DONE)

> Testing (~)

> Provisioning admin (~)

> Sending Mails (~) 

> Building more endpoints (~)

> Optimizing (~)

> Messaging (~)


## Documentation

Please find API docs @ [here](https://api.schoolsilo.cloud/api/documentation).